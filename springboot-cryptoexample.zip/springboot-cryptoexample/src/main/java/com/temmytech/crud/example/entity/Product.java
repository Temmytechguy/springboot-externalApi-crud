package com.temmytech.crud.example.entity;

import lombok.*;

import javax.persistence.*;
/****
 * @author Temidayo Folorunsho
 * @Date 11/April/2022
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "PRODUCT_TBL")
public class Product {


    @Id
    @GeneratedValue
    private int id;
    private String name;
    private double amountPurchased;
    private String dateOfEntry;
    private String walletLocation;
    @Transient
    private double lastPrice;

    @Transient
    private double volume;
    private float marketValueAtEntry;
    private float currentMarketValue;





}
