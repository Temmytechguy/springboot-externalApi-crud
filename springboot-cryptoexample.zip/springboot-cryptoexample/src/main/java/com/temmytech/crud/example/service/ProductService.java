package com.temmytech.crud.example.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.temmytech.crud.example.entity.MarketApi;
import com.temmytech.crud.example.entity.Product;
import com.temmytech.crud.example.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/****
 * @author Temidayo Folorunsho
 * @Date 11/April/2022
 */

@Service
public class ProductService {

    @Autowired
    private ProductRepository repository;


    private MarketApi api;





    //add a Product
    public Product saveProduct(Product product)
    {
        ObjectMapper oMapper = new ObjectMapper();

        addApiToMarket();

        Map<String, Object> map = oMapper.convertValue(api, Map.class);
        System.out.println("successfully output " + map);

       //set date and time ot the Product entity
        LocalDateTime currentDate = LocalDateTime.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        String formattedDateTime = currentDate.format(format);


          product.setDateOfEntry(formattedDateTime);
          product.setLastPrice((int) map.get("lastPrice"));
          product.setVolume((Double) map.get("volume"));
//          int lastPrice = (int) map.get("lastPrice");
//          double volume = (double) map.get("volume");
          float entryValue = (float) (product.getLastPrice() * product.getVolume());

          //set the product to the market entry value
          product.setMarketValueAtEntry(entryValue);

          int currentPrice = (int) map.get("lastPrice");
          double currentVolume = (double) map.get("volume");
          float currentMarketValue = (float) (currentPrice * currentVolume);

          //set the current market price value
          product.setCurrentMarketValue(currentMarketValue);


        System.out.println("I made a purchase of: " + product.getAmountPurchased() + " btc " +
                " on  " + formattedDateTime);


            return repository.save(product);
    }

    //add list of products
    public List<Product> saveProducts(List<Product> products)
    {
        return repository.saveAll(products);
    }


    // list all entries
    public List<Product> getAllProducts(){

        return repository.findAll();
    }

    //get a single entry by id
    public Product getProductById(int id){
        return repository.findById(id).orElse(null);
    }

    //get a single entry by name
    public Product getProductByName(String name){
        return repository.findByName(name);
    }


    //delete an Product  by id
    public String deleteProduct(int id){
        repository.deleteById(id);
        return "Product removed" + id;
    }



    //update an Product
    public Product update(Product product)
    {
        Product existingProduct =repository.findById(product.getId()).orElse(null);
        existingProduct.setName(product.getName());
        existingProduct.setAmountPurchased(product.getAmountPurchased());
        existingProduct.setWalletLocation(product.getWalletLocation());
        //existingProduct.setCurrentMarketValue(product.getCurrentMarketValue());
        return repository.save(existingProduct);
    }


//    public Map<String, Object> getApi (){
//        Map<String, Object> marketList = new HashMap<String, Object>();
//        List<Object> allMarkets;
//        String url1 = "https://run.mocky.io/v3/c61c4147-5fbe-43fe-a333-187fc3b28a76";
//        String apiURL = "https://api-pub.bitfinex.com/v2/tickers?symbols=tBTCUSD";
//        RestTemplate restTemplate = new RestTemplate();
//        allMarkets = restTemplate.getForObject(apiURL, List.class);
//
//        //cast the json response to a list object
//        List<Object> list1 = (List<Object>) allMarkets.get(0);
//        for(int i = 0; i < list1.size(); i++)
//        {
//
//            marketList.put("SYMBOLS", list1.get(0));
//            marketList.put("BID", list1.get(1));
//            marketList.put("BID_SIZE", list1.get(2));
//            marketList.put("ASK", list1.get(3));
//            marketList.put("ASK_SIZE", list1.get(4));
//            marketList.put("DAILY_CHANGE", list1.get(5));
//            marketList.put("DAILY_CHANGE_RELATIVE", list1.get(6));
//            marketList.put("LAST_PRICE", list1.get(7));
//            marketList.put("VOLUME", list1.get(8));
//            marketList.put("HIGH", list1.get(9));
//            marketList.put("LOW", list1.get(10));
//
//        }
//        for (String key : marketList.keySet()) {
//            System.out.println(key + " : " + marketList.get(key));
//        }
//        return marketList;
//    }
    public void addApiToMarket() {

        List<Object> allMarkets;
        //String url1 = "https://run.mocky.io/v3/c61c4147-5fbe-43fe-a333-187fc3b28a76";
        String apiURL = "https://api-pub.bitfinex.com/v2/tickers?symbols=tBTCUSD";
        RestTemplate restTemplate = new RestTemplate();
        allMarkets = restTemplate.getForObject(apiURL, List.class);


        //cast the json response to a list object
        List<Object> list1 = (List<Object>) allMarkets.get(0);

        api = new MarketApi();

        api.setName((String) list1.get(0));
        api.setBid((int) list1.get(1));
        api.setBID_SIZE((double) list1.get(2));
        api.setAsk((int) list1.get(3));
        api.setAskSize((double) list1.get(4));
        api.setDailyChange((double) list1.get(5));
        api.setDailyChangeRelative((double) list1.get(6));
        api.setLastPrice((int) list1.get(7));
        api.setVolume((double) list1.get(8));
        api.setHigh((int) list1.get(9));
        api.setLow((int) list1.get(10));


    }





}


