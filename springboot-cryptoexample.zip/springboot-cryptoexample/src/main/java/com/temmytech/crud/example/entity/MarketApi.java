package com.temmytech.crud.example.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
/****
 * @author Temidayo Folorunsho
 * @Date 11/April/2022
 */
@Data
@AllArgsConstructor
public  class MarketApi {
    @Id
    @GeneratedValue
    private int id;
    private String name;
    private int bid;
    private double BID_SIZE;
    private int ask;
    private double askSize;
    private double dailyChange;
    private double dailyChangeRelative;
    private int lastPrice;
    private double volume;
    private int high;
    private int low;

    public MarketApi(){

    }






}
