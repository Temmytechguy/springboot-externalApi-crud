package com.temmytech.crud.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCryptoexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
